# !/usr/bin/env python3
# coding: utf-8
import math
import rospy
import threading
import Arm_Lib
import time
from dofbot_info.srv import kinemarics, kinemaricsRequest, kinemaricsResponse


class Control_Coord:
    def __init__(self):
        self._Arm = Arm_Lib.Arm_Device()


        self.n = rospy.init_node('dofbot_control_coord', anonymous=True)
        # 创建用于调用的ROS服务的句柄 Create a handle to the ROS service to invoke
        self.client = rospy.ServiceProxy("dofbot_kinemarics", kinemarics)

    # 坐标转换成角度
    def coord_to_angles(self, coords):
        '''
        Post position request, get joint rotation angle
        发布位置请求,获取关节旋转角度
        '''
        # if len(coords) != 3:
        #     print("input error.coords=[x, y, z]")
        #     return False, None
        request = kinemaricsRequest()
        request.tar_x = coords[0]
        request.tar_y = coords[1]
        request.tar_z = coords[2]
        # request.Roll  = coords[3]
        # request.Pitch = coords[4]
        # request.Yaw   = coords[5]
        request.Roll  = 2.5*request.tar_y*100-207.5
        request.Pitch = 0
        request.Yaw   = 0
        request.kin_name = "ik"
        try:
            response = self.client.call(request)
            if isinstance(response, kinemaricsResponse):
                # Get the inverse solution response result
                # 获得反解响应结果
                joints = [0.0, 0.0, 0.0, 0.0, 0.0]
                joints[0] = round(response.joint1, 2)
                joints[1] = round(response.joint2, 2)
                joints[2] = round(response.joint3, 2)
                joints[3] = round(response.joint4, 2)
                joints[4] = round(response.joint5, 2)
                return True, joints
        except Exception:
            rospy.loginfo("coord_to_angles error")
        return False, None


    # 控制机器人运动
    def ctrl_move(self, p, time_ms, delay=False):
        for i in range(5):
            s_id = i + 1
            self._Arm.Arm_serial_servo_write(s_id, p[i], int(time_ms))
            time.sleep(.002)
        if delay and time_ms > 0:
            time.sleep(time_ms/1000.0)

    # 控制夹爪
    def ctrl_gripper(self, value, time_ms, delay=False):
        if value > 180: value = 180
        if value < 0: value = 0
        self._Arm.Arm_serial_servo_write(6, int(value), int(time_ms))
        if delay and time_ms > 0:
            time.sleep(time_ms/1000.0)
