# !/usr/bin/env python3
# coding: utf-8
import time
from pyorbbecsdk import *


class Pyorb_Config:
    def __init__(self):
        self.context = Context()
        self.device_list = self.context.query_devices()
        self.device = self.device_list.get_device_by_index(0)
        self.pipeline = Pipeline(self.device)

        self.DEF_COLOR_EXPOSURE = 50

    def __del__(self):
        self.pipeline = None
        self.device = None
        self.context = None
        del self.pipeline
        del self.device
        del self.context
        
    # 读取设备信息
    def get_device_info(self):
        device_info = self.device.get_device_info()
        # print("device_info:", device_info)
        return device_info

    # 读取相机名称
    def get_device_name(self):
        device_info = self.device.get_device_info()
        device_name = device_info.get_name()
        # print("device_name:", device_name)
        return device_name


    # 设置颜色相机的自动曝光功能开关
    def set_color_auto_exposure_state(self, enable=False):
        if enable:
            self.device.set_bool_property(OBPropertyID.OB_PROP_COLOR_AUTO_EXPOSURE_BOOL, True)
        else:
            self.device.set_bool_property(OBPropertyID.OB_PROP_COLOR_AUTO_EXPOSURE_BOOL, False)

    # 设置当前颜色相机的曝光值
    def set_color_exposure(self, exposure):
        self.device.set_int_property(OBPropertyID.OB_PROP_COLOR_EXPOSURE_INT, exposure)


    # 读取当前颜色相机的曝光值
    def get_color_exposure(self):
        curr_color_exposure = self.device.get_int_property(OBPropertyID.OB_PROP_COLOR_EXPOSURE_INT)
        # print("curr_color_exposure:", curr_color_exposure)
        return curr_color_exposure

    # 设置彩色相机默认参数
    def default_color_config(self):
        self.set_color_auto_exposure_state(False)
        time.sleep(.1)
        self.set_color_exposure(self.DEF_COLOR_EXPOSURE)
        time.sleep(.1)
        self.set_color_mirror(False)
        time.sleep(.1)

    # 设置彩色相机镜像显示
    def set_color_mirror(self, enable=False):
        if enable:
            self.device.set_bool_property(OBPropertyID.OB_PROP_COLOR_MIRROR_BOOL, True)
        else:
            self.device.set_bool_property(OBPropertyID.OB_PROP_COLOR_MIRROR_BOOL, False)