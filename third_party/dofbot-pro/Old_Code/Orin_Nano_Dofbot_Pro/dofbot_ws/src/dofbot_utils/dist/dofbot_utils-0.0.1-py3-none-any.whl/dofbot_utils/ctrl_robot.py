# !/usr/bin/env python3
# coding: utf-8
from Arm_Lib import Arm_Device
import time


class Ctrl_Robot:
    def __init__(self):

        self.Arm = Arm_Device()

        self.gripper_clamp = 135
        self.gripper_release = 30
        self.joint5 = 90

        self.P_TOP = [90, 80, 50, 50, 90, self.gripper_clamp]
        self.P_BLUE = [0, 40, 60, 0, 90, self.gripper_clamp]
        self.P_GREEN = [180, 40, 60, 0, 90, self.gripper_clamp]
        self.P_RED = [30, 30, 75, 0, 120, self.gripper_clamp]
        self.P_YELLOW = [150, 30, 75, 0, 60, self.gripper_clamp]
        self.P_CENTER = [90, 35, 70, -3, 90, self.gripper_clamp]

        self.P_HEAP_1 = [180, 38, 58, 0, 90, self.gripper_clamp]
        self.P_HEAP_2 = [180, 52, 48, 0, 90, self.gripper_clamp]
        self.P_HEAP_3 = [180, 72, 40, 0, 90, self.gripper_clamp]
        self.P_HEAP_4 = [180, 105, 12, 10, 90, self.gripper_clamp]

        self.P_CENTER_1 = [90, 38, 58, 0, 90, self.gripper_clamp]
        self.P_CENTER_2 = [90, 52, 48, 0, 90, self.gripper_clamp]
        self.P_CENTER_3 = [90, 72, 40, 0, 90, self.gripper_clamp]
        self.P_CENTER_4 = [90, 105, 12, 10, 90, self.gripper_clamp]

        self.P_CENTER_L1 = [90, 38, 58, 0, 90, self.gripper_clamp]
        self.P_CENTER_L2 = [90, 52, 48, 0, 90, self.gripper_clamp]
        self.P_CENTER_L3 = [90, 72, 40, 0, 90, self.gripper_clamp]
        self.P_CENTER_L4 = [90, 105, 12, 10, 90, self.gripper_clamp]

        self.P_NUM_1 = [150, 30, 75, 0, 60, self.gripper_clamp]
        self.P_NUM_2 = [180, 40, 60, 0, 90, self.gripper_clamp]
        self.P_NUM_3 = [30, 30, 75, 0, 120, self.gripper_clamp]
        self.P_NUM_4 = [0, 40, 60, 0, 90, self.gripper_clamp]

        # self.P_RECYCLABLE_WATE = [143, 23, 90, 0, 50, self.gripper_clamp]
        self.P_RECYCLABLE_WATE = [15, 40, 60, 0, 100, self.gripper_clamp]
        self.P_KITCHEN_WASTE = [165, 40, 60, 0, 70, self.gripper_clamp]
        self.P_HAZARDOUS_WASTE = [38, 23, 90, 0, 130, self.gripper_clamp]
        self.P_OTHER_WASTE = [143, 23, 90, 0, 50, self.gripper_clamp]


        self.P_LOOK_AT = [90, 164, 18, 0, 90, self.gripper_release]
        self.P_LOOK_MAP = [90, 106, 0, 3, 90, self.gripper_release]
        self.P_LOOK_FRONT = [90, 135, 20, 25, 90, self.gripper_release]

        self.P_ACTION_1 = [90, 90, 90, 90, 90, 180]
        self.P_ACTION_2 = [90, 90, 0, 180, 90, 180]
        self.P_ACTION_3 = [90, 131, 52, 0, 90, 180]
        self.P_ACTION_4 = [90, 0, 180, 20, 90, 30]
        self.P_ACTION_5 = [90, 0, 90, 180, 90, 0]

        self.P_FINGER_START = [90, 131, 52, 0, 90, 180]


    def arm_move(self, p, time_ms, delay=False):
        for i in range(5):
            s_id = i + 1
            self.Arm.Arm_serial_servo_write(s_id, p[i], int(time_ms))
            time.sleep(.002)
        if delay and time_ms > 0:
            time.sleep(time_ms/1000.0)

    def arm_move_6(self, joint6_array, time_ms, delay=False):
        if len(joint6_array) == 6:
            self.Arm.Arm_serial_servo_write6_array(joint6_array, time_ms)
            if delay and time_ms > 0:
                time.sleep(time_ms/1000.0)

    def arm_clamp_block(self, state, time_ms=500, delay=False):
        if state:
            self.Arm.Arm_serial_servo_write(6, self.gripper_clamp, int(time_ms))
        else:
            self.Arm.Arm_serial_servo_write(6, self.gripper_release, int(time_ms))


    def ctrl_gripper(self, value, time_ms, delay=False):
        if value > 180: value = 180
        if value < 0: value = 0
        self.Arm.Arm_serial_servo_write(6, int(value), int(time_ms))
        if delay and time_ms > 0:
            time.sleep(time_ms/1000.0)

    def get_gripper_value(self, state):
        if state == 0:
            return self.gripper_release
        return self.gripper_clamp

    # 机械臂看地图
    def move_look_map(self, time_ms=1000, delay=False):
        self.Arm.Arm_serial_servo_write6_array(self.P_LOOK_MAP, time_ms)
        if delay:
            time.sleep(time_ms/1000.0)
    
    # 机械臂初始状态，看前面
    def move_init_pose(self, time_ms=1000, delay=False):
        self.Arm.Arm_serial_servo_write6_array(self.P_LOOK_AT, time_ms)
        if delay:
            time.sleep(time_ms/1000.0)
    
    # 机械臂看前面
    def move_look_front(self, time_ms=1000, delay=False):
        self.Arm.Arm_serial_servo_write6_array(self.P_LOOK_FRONT, time_ms)
        if delay:
            time.sleep(time_ms/1000.0)


    
